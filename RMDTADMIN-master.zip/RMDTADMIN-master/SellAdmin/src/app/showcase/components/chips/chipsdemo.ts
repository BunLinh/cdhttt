import {Component} from '@angular/core';

@Component({
    templateUrl: './chipsdemo.html'
})
export class ChipsDemo {

    values1: string[];
    
    values2: string[];
}