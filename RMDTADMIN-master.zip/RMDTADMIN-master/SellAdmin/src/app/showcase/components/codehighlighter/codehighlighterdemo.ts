import {Component} from '@angular/core';

@Component({
    templateUrl: './codehighlighterdemo.html'
})
export class CodeHighlighterDemo {
    
}