export class TopicCreation {
    topicName: string;
    topicDescription: string;
    topicStatus: number;
}
