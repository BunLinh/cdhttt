export class CourseCreate {
    private courseTitle: string;
    private courseDescription: string;
    private price: number;
    private courseTypeID: string;
    private topicID: string;
    private courseAvatar: string;
    private ScourseDetail: string;
}
