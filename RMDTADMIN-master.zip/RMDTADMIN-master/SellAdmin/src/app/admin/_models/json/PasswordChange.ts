export class PasswordChange {
    private oldPassword: string;
    private newPassword: string;
}
