export class FileOfLesson {
    lessonAttachID: string;
    lessonID: string;
    lesonAttachContent: string;
    dayAdded: any;
}
