export  class Lesson {
    lessonID: string;
    lessonTitle: string;
    lessonContent: string;
    chapterID: string;
    views: number;
    listOfComments: Comment[];
}
