import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thong-ke-chu-de-theo-luoc-xem',
  templateUrl: './thong-ke-chu-de-theo-luoc-xem.component.html',
  styleUrls: ['./thong-ke-chu-de-theo-luoc-xem.component.css']
})
export class ThongKeChuDeTheoLuocXemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
