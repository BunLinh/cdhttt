// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';
// import { CustomerEditComponent } from './edit-customer.component';
// import { NgModule } from '@angular/core';
// import { CodeHighlighterModule } from './../../../../components/codehighlighter/codehighlighter';
// import { TabViewModule } from './../../../../components/tabview/tabview';
// import { ButtonModule } from './../../../../components/button/button';
// import { InputTextareaModule } from './../../../../components/inputtextarea/inputtextarea';
// import { PanelModule } from './../../../../components/panel/panel';
// import { InputTextModule } from './../../../../components/inputtext/inputtext';
// import { DropdownModule } from './../../../../components/dropdown/dropdown';
// import { GrowlModule } from './../../../../components/growl/growl';


// import { EditCustomerRoutingModule } from '../edit-customer/edit-customer-routing.module';

// @NgModule({
//     imports: [
//         CommonModule,
//         FormsModule,
//         ReactiveFormsModule,
//         EditCustomerRoutingModule,
//         GrowlModule,
//         PanelModule,
//         DropdownModule,
//         InputTextModule,
//         InputTextareaModule,
//         ButtonModule,
//         TabViewModule,
//         CodeHighlighterModule
//     ],
//     exports: [],
//     declarations: [
//         CustomerEditComponent
//     ],
//     providers: [],
// })
// export class EditCustomerModule { }
