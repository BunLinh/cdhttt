import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'mau-demo.component.html'
})

export class MauDemoComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}