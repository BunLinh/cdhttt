# 3TPL

![Feels](http://emojipedia-us.s3.amazonaws.com/content/2015/10/11/facebook-emoji-reactions.gif)

## Mô tả 
Trang web thương mại điện tử với chủ đề khóa học trực tuyến 3TPL.

## Nhóm phát triển
* Trần Văn Thắng
* Huỳnh Tính Thành
* Phạm Thị Mỹ Trinh
* Nguyễn Tấn Phát
* Trương Tam Lang

## Cấu trúc
1. Phần người dùng https://github.com/nguyenphatit/TMDTSellPage
1. Phần quản lý https://github.com/tinhthanh/RMDTADMIN
1. Phần kết nối dữ liệu https://github.com/ttlang/TMDT_REST_V2

## Công nghệ sử dụng
1. Angular 4
1. Twitter Bootstrap 4
1. Sass
1. MySQL
1. Spring
1. Mybatis
