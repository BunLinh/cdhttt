
import { Course } from '../../_models/index';

export class DataCourse {
    public listDataCourse: Course[] = [];
    constructor() {
    }
    public addCourse(course: Course) {
    }
}
