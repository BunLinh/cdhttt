import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'home-demo.component.html'
})

export class DemoComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}