export class Role {
     roleID: number;
     roleName: string;
    constructor(roleID: number , roleName: string){
        this.roleID = roleID ;
        this.roleName = roleName;
    }
}
