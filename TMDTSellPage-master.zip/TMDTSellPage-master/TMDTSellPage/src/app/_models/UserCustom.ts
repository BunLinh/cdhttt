export class UserCustom {
   private userID: string;
    private userName: string;
    private email: string;
    private avatar: string;
    private address: string;
    private phoneNumber: string;
}
