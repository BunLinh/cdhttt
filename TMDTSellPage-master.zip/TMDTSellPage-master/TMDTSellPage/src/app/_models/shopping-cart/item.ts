export class Item {
    public id ;
    public name ;
    public image;
    public count;
    public price;
}