export  class Lesson {
   private lessonID: string;
   private lessonTitle: string;
   private lessonContent: string;
   private chapterID: string;
   private views: number;
   private listOfComments: Comment[];
}
