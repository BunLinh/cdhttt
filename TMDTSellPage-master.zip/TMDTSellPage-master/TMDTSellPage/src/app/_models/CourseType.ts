export class CourseType {
    private courseTypeID: string;
    private courseTitle: string;
    private courseDescription: string;
}
