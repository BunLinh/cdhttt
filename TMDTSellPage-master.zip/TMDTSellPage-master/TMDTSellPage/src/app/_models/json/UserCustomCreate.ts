export class UserCustomCreate {
     userName: string;
     email: string;
     password: string;
}
