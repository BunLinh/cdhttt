export class PasswordReset {
    private newPassword: string;
    private key: string;
}
